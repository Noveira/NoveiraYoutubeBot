# 🎥 Discord YouTube Notifier — Railway Edition

YouTube'a yeni video yüklendiğinde Discord kanalına otomatik bildirim gönderen bot.
**Railway üzerinde 7/24 ücretsiz çalışır.**

---

## 🚀 Railway'e Deploy Adımları

### 1. GitHub'a Yükle
```bash
git init
git add .
git commit -m "Discord YouTube Notifier"
git remote add origin https://github.com/KULLANICI_ADIN/REPO_ADIN.git
git push -u origin main
```

### 2. Railway Hesabı Aç
- https://railway.app adresine git
- **GitHub ile giriş yap** (ücretsiz)

### 3. Yeni Proje Oluştur
1. **New Project** → **Deploy from GitHub repo**
2. Repo'nu seç → **Deploy Now**

### 4. Environment Variables Ekle ⚠️ EN ÖNEMLİ ADIM
Railway Dashboard → Projen → **Variables** sekmesi → **New Variable**:

| Değişken Adı | Değer |
|---|---|
| `DISCORD_BOT_TOKEN` | Discord bot token'ın |
| `DISCORD_CHANNEL_ID` | Bildirim kanalının ID'si |
| `YOUTUBE_CHANNEL_ID` | UC ile başlayan YouTube kanal ID'n |
| `CHECK_INTERVAL_MINUTES` | `5` (kaç dakikada bir kontrol) |
| `NOTIFICATION_MESSAGE` | `🎥 Yeni video yayınlandı!` |

5 değişkeni girdikten sonra Railway otomatik olarak yeniden deploy eder.

### 5. Logları Kontrol Et
Railway Dashboard → **Deployments** → son deploy'a tıkla → **Logs**

Şunu görmelisin:
```
Discord YouTube Notifier v1.0.0
[Config] ✅ Tüm ayarlar yüklendi.
[Discord] ✅ Bağlandı → BotAdın#1234
[Main] ✅ Bot Railway'de çalışıyor!
```

---

## 📁 Proje Yapısı

```
discord-youtube-notifier/
├── Dockerfile                     ← Railway bunu kullanarak çalıştırır
├── railway.toml                   ← Railway konfigürasyonu
├── pom.xml                        ← Maven bağımlılıkları
├── .gitignore                     ← Güvenlik (token dosyaları hariç tutulur)
└── src/main/java/com/yourtag/notifier/
    ├── Main.java
    ├── config/Config.java          ← Environment variable'ları okur
    ├── youtube/YouTubePoller.java  ← RSS feed kontrol
    └── discord/DiscordNotifier.java
```

---

## ❓ Sık Sorulan Sorular

**Ücretsiz plan ne kadar süre çalışır?**
Railway ücretsiz planda aylık 500 saat veriyor. 1 bot = ~720 saat/ay gerektirir.
Kredi kartı ekleyince limit kalkar ama bot bu kadar az kaynak tüketir ki ücret çıkmaz.

**config.json yok, token nereye girilirim?**
Kod kasıtlı olarak token'ı dosyadan okumaz — Railway Variables'a girmen gerekir. Güvenlik için böyle yapıldı.

**Deploy oldu ama bildirim gelmiyor?**
1. Variables sekmesinde tüm 5 değişkenin olduğunu kontrol et
2. Discord bot'unun kanala mesaj gönderme izninin olduğunu kontrol et
3. YouTube Channel ID'nin `UC` ile başladığını kontrol et
